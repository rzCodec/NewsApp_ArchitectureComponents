package myapp.newsapp_architecturecomponents.view_model;

import androidx.lifecycle.LiveData;
import myapp.newsapp_architecturecomponents.repository.BusinessNews;

import java.util.List;

public interface iDataHandler {
    LiveData<List<BusinessNews>> getBusinessNewsItems();
}
