package myapp.newsapp_architecturecomponents.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import myapp.newsapp_architecturecomponents.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*
        //Get the viewpager and instantiate the pager adapter
        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        NewsPagerAdapter npa = new NewsPagerAdapter(getSupportFragmentManager(), "Business", "Weather");
        //Set the viewpager to the pager adapter
        viewPager.setAdapter(npa);
        //Get the tab layout and then set it with the viewpager
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tablayout);
        tabLayout.setupWithViewPager(viewPager);*/
    }
}
