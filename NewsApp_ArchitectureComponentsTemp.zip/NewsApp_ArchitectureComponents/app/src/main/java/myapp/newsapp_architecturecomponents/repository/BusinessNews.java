package myapp.newsapp_architecturecomponents.repository;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import com.google.gson.annotations.SerializedName;

@Entity(tableName = "business_news_table")
public class BusinessNews implements Parcelable {

    @PrimaryKey(autoGenerate = true)
    private int id;

    //SerializedName annotation is used for GSON and Retrofit object conversion
    @SerializedName("article_title")
    private String article_title;

    @SerializedName("article_date")
    private String article_date;

    @SerializedName("article_content")
    private String article_content;

    public BusinessNews(String article_title, String article_date, String article_content) {
        this.article_title = article_title;
        this.article_date = article_date;
        this.article_content = article_content;
    }

    //Set method for the id so Room can set the id automatically
    public void setID(int id) {
        this.id = id;
    }

    //Getters
    public int getId() {
        return id;
    }

    public String getArticle_title() {
        return article_title;
    }

    public String getArticle_date() {
        return article_date;
    }

    public String getArticle_content() {
        return article_content;
    }

    //Parcelable methods --------------------------------------------------------------
    private BusinessNews(Parcel parcel) {
        this.article_title = parcel.readString();
        this.article_date = parcel.readString();
        this.article_content = parcel.readString();
    }

    public static final Parcelable.Creator<BusinessNews> CREATOR = new Parcelable.Creator<BusinessNews>() {
        public BusinessNews createFromParcel(Parcel in) {
            return new BusinessNews(in); //Refer to the private Subject Constructor
        }

        public BusinessNews[] newArray(int size) {
            return new BusinessNews[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.article_title);
        parcel.writeString(this.article_date);
        parcel.writeString(this.article_content);

    }
}
