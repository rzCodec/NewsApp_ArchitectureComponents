package myapp.newsapp_architecturecomponents.ui;


import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import myapp.newsapp_architecturecomponents.R;
import myapp.newsapp_architecturecomponents.repository.BusinessNews;
import myapp.newsapp_architecturecomponents.view_model.NewsFeed_ViewModel;

import java.util.List;

public class NewsFeedFragment extends Fragment {

    private NewsFeed_ViewModel newsFeed_viewModel;
    private View view;

    public static NewsFeedFragment newInstance() {
        return new NewsFeedFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.temp_fragment, container, false);;
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        newsFeed_viewModel = ViewModelProviders.of(this).get(NewsFeed_ViewModel.class);
        newsFeed_viewModel.getBusinessNewsItems().observe(this, new Observer<List<BusinessNews>>() {
            @Override
            public void onChanged(List<BusinessNews> businessNews) {
                //Update the UI
            }
        });
    }

}
