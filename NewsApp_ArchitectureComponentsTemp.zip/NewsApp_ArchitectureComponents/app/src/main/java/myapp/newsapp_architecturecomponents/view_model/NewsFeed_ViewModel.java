package myapp.newsapp_architecturecomponents.view_model;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;
import myapp.newsapp_architecturecomponents.repository.BusinessNews;
import myapp.newsapp_architecturecomponents.repository.web_repository.API_repository;

import java.util.List;

/**
 * Class for the UI that the user views their news in real time
 */
public class NewsFeed_ViewModel extends ViewModel implements iDataHandler{
    private LiveData<List<BusinessNews>> newsList;
    private API_repository api_repository;

    public NewsFeed_ViewModel() {
        api_repository = new API_repository();
    }

    @Override
    public LiveData<List<BusinessNews>> getBusinessNewsItems() {
        return api_repository.getArticleContent();
    }
}
